#ifndef MAINWIDOW_H
#define MAINWIDOW_H

#include <QMainWindow>

namespace Ui {
class MainWidow;
}

class MainWidow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWidow(QWidget *parent = 0);

    ~MainWidow();

private slots:
    void on_pushButtonClose_clicked();

    void on_nextStage_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_reset_clicked();

    void on_run10ClockCycle_clicked();

private:
    Ui::MainWidow *ui;

protected:
     void closeEvent(QCloseEvent *event);
};

#endif // MAINWIDOW_H
