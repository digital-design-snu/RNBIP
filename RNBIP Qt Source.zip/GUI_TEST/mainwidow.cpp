#include "mainwidow.h"
#include "ui_mainwidow.h"
#include <QPixmap>
#include <string.h>
#include <fstream>
#include <QDebug>
#include <QProcess>
#include <QPoint>
#include <QHBoxLayout>
#include <QDesktopWidget>
#include <QDir>
#include <QTime>
#include <QStyleFactory>
#include <QPalette>
#include <QStandardItemModel>
#include <sstream>
#include <QFileInfo>
#include <QThread>
#include <QCloseEvent>
#include <QDesktopServices>
//#ifdef _WIN32
//#include <windows.h>

//#endif

using namespace std;

bool statusCurrent = false;
int currentPosition = 0;
bool isFirstFetch = false;
bool IR = false;
char temp[3] = "";
QTableWidget *table;
QTableWidget *stack;
QProcess *process;
int executionState = 0;

void setNextValues();
void readNextSet();
bool fileExists(QString path);

void MainWidow::closeEvent (QCloseEvent *event)
{
    ofstream f1 ("sig.dat");
    f1 << "1" <<'\n';
    f1.close();
}

MainWidow::MainWidow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWidow)
{
    remove("sig.dat");
    ofstream f1 ("sig.dat");
    f1 << "0" <<'\n';
    f1.close();
    ui->setupUi(this);
    QWidget::showMaximized();
    setWindowFlags(Qt::Window | Qt::WindowMinimizeButtonHint | Qt::WindowCloseButtonHint);
  //  resize(QDesktopWidget().availableGeometry(this).size());
    //QWidget::setGeometry(0,0,1366,728);

    this->setWindowTitle("Single-Bus Processor");

    process = new QProcess(this);

    int h = QWidget::height()-100;
    int w = QWidget::width()-500;

    QPixmap pix(":/resources/img/back_final.png");
    ui->imageLabel_Source->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_1(":/resources/img/RD.png");
    ui->imageLabel->setPixmap(pix_1.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_2(":/resources/img/WR.png");
    ui->imageLabel_2->setPixmap(pix_2.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_3(":/resources/img/S_PC.png");
    ui->imageLabel_3->setPixmap(pix_3.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_4(":/resources/img/S_SP.png");
    ui->imageLabel_4->setPixmap(pix_4.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_5(":/resources/img/E_PC.png");
    ui->imageLabel_5->setPixmap(pix_5.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_6(":/resources/img/I_PC.png");
    ui->imageLabel_6->setPixmap(pix_6.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_7(":/resources/img/L_PC.png");
    ui->imageLabel_7->setPixmap(pix_7.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_8(":/resources/img/E_SP.png");
    ui->imageLabel_8->setPixmap(pix_8.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_9(":/resources/img/D_SP.png");
    ui->imageLabel_9->setPixmap(pix_9.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_10(":/resources/img/I_SP.png");
    ui->imageLabel_10->setPixmap(pix_10.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_11(":/resources/img/L_IR.png");
    ui->imageLabel_11->setPixmap(pix_11.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_12(":/resources/img/E_FL.png");
    ui->imageLabel_12->setPixmap(pix_12.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_13(":/resources/img/S_IF.png");
    ui->imageLabel_13->setPixmap(pix_13.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_14(":/resources/img/E_IP.png");
    ui->imageLabel_14->setPixmap(pix_14.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_15(":/resources/img/L_OP.png");
    ui->imageLabel_15->setPixmap(pix_15.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_16(":/resources/img/E_OR.png");
    ui->imageLabel_16->setPixmap(pix_16.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_17(":/resources/img/L_OR.png");
    ui->imageLabel_17->setPixmap(pix_17.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_18(":/resources/img/S_AL.png");
    ui->imageLabel_18->setPixmap(pix_18.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_19(":/resources/img/L_R0.png");
    ui->imageLabel_19->setPixmap(pix_19.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_20(":/resources/img/E_R0.png");
    ui->imageLabel_20->setPixmap(pix_20.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_21(":/resources/img/L_RN.png");
    ui->imageLabel_21->setPixmap(pix_21.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_22(":/resources/img/E_RN.png");
    ui->imageLabel_22->setPixmap(pix_22.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_23(":/resources/img/Databus.png");
    ui->imageLabel_23->setPixmap(pix_23.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_24(":/resources/img/L_SP.png");
    ui->imageLabel_24->setPixmap(pix_24.scaled(w,h,Qt::KeepAspectRatio));

//    QPixmap killLRN(":/resources/img/killLRN.png");
//    ui->imageLabel_25->setPixmap(killLRN.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_26(":/resources/img/killLRN2.png");
    ui->imageLabel_26->setPixmap(pix_26.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_27(":/resources/img/killLR0.png");
    ui->imageLabel_27->setPixmap(pix_27.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_28(":/resources/img/C_yes.png");
    ui->imageLabel_28->setPixmap(pix_28.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_29(":/resources/img/C_no.png");
    ui->imageLabel_29->setPixmap(pix_29.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_30(":/resources/img/Z_yes.png");
    ui->imageLabel_30->setPixmap(pix_30.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_31(":/resources/img/Z_no.png");
    ui->imageLabel_31->setPixmap(pix_31.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_32(":/resources/img/P_yes.png");
    ui->imageLabel_32->setPixmap(pix_32.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_33(":/resources/img/P_no.png");
    ui->imageLabel_33->setPixmap(pix_33.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_34(":/resources/img/OP_yes.png");
    ui->imageLabel_34->setPixmap(pix_34.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_35(":/resources/img/OP_no.png");
    ui->imageLabel_35->setPixmap(pix_35.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_36(":/resources/img/SAF_activated.png");
    ui->imageLabel_36->setPixmap(pix_36.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_37(":/resources/img/OD_PC.png");
    ui->imageLabel_37->setPixmap(pix_37.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_38(":/resources/img/specialPath.png");
    ui->imageLabel_38->setPixmap(pix_38.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_39(":/resources/img/killLPC.png");
    ui->imageLabel_39->setPixmap(pix_39.scaled(w,h,Qt::KeepAspectRatio));

    QPixmap pix_40(":/resources/img/R0_AS.png");
    ui->imageLabel_40->setPixmap(pix_40.scaled(w,h,Qt::KeepAspectRatio));


    QRect rect(QPoint(20,0),QSize(620,685));
//    QPoint *pt = new QPoint();
//    pt->setX(180);
//    pt->setY(30);

//    rect->setTopLeft(pt);
    ui->imageLabel_Source->setGeometry(rect);
    ui->imageLabel->setGeometry(rect);
    ui->imageLabel_2->setGeometry(rect);
    ui->imageLabel_3->setGeometry(rect);
    ui->imageLabel_4->setGeometry(rect);
    ui->imageLabel_5->setGeometry(rect);
    ui->imageLabel_6->setGeometry(rect);
    ui->imageLabel_7->setGeometry(rect);
    ui->imageLabel_8->setGeometry(rect);
    ui->imageLabel_9->setGeometry(rect);
    ui->imageLabel_10->setGeometry(rect);
    ui->imageLabel_11->setGeometry(rect);
    ui->imageLabel_12->setGeometry(rect);
    ui->imageLabel_13->setGeometry(rect);
    ui->imageLabel_14->setGeometry(rect);
    ui->imageLabel_15->setGeometry(rect);
    ui->imageLabel_16->setGeometry(rect);
    ui->imageLabel_17->setGeometry(rect);
    ui->imageLabel_18->setGeometry(rect);
    ui->imageLabel_19->setGeometry(rect);
    ui->imageLabel_20->setGeometry(rect);
    ui->imageLabel_21->setGeometry(rect);
    ui->imageLabel_22->setGeometry(rect);
    ui->imageLabel_23->setGeometry(rect);
    ui->imageLabel_24->setGeometry(rect);
//    ui->imageLabel_25->setGeometry(rect);
    ui->imageLabel_26->setGeometry(rect);
    ui->imageLabel_27->setGeometry(rect);
    ui->imageLabel_28->setGeometry(rect);
    ui->imageLabel_29->setGeometry(rect);
    ui->imageLabel_30->setGeometry(rect);
    ui->imageLabel_31->setGeometry(rect);
    ui->imageLabel_32->setGeometry(rect);
    ui->imageLabel_33->setGeometry(rect);
    ui->imageLabel_34->setGeometry(rect);
    ui->imageLabel_35->setGeometry(rect);
    ui->imageLabel_36->setGeometry(rect);
    ui->imageLabel_37->setGeometry(rect);
    ui->imageLabel_38->setGeometry(rect);
    ui->imageLabel_39->setGeometry(rect);
    ui->imageLabel_40->setGeometry(rect);

    stack = ui->tableWidget_2;
    stack->setRowCount(1);
    stack->setColumnCount(1);

    stack->verticalHeader()->setVisible(false);

    QTableWidgetItem *headerx = new QTableWidgetItem();
    headerx->setText("TOS");
    stack->setHorizontalHeaderItem(0,headerx);


    table= ui->tableWidget;
    table->setRowCount(256);
    table->setColumnCount(2);
    table->verticalHeader()->setVisible(false);

    QTableWidgetItem *header2 = new QTableWidgetItem();
    header2->setText("Value");
    table->setHorizontalHeaderItem(1,header2);

    QTableWidgetItem *header1 = new QTableWidgetItem();
    header1->setText("Address");
    table->setHorizontalHeaderItem(0,header1);

    QRect rect2(QPoint(0,0),QSize(QWidget::width(),QWidget::height()));
    ui->scrollArea->setWidget(ui->logBox);
    ui->PC_value->setText("0");
    ui->SP_value->setText("FF");
    ui->IR_value->setText("Opcode : XX");
    ui->OR_value->setText("XX");
    ui->Instruction_value->setText("Instruction : XX");
    ui->run10ClockCycle->setVisible(false);
}

MainWidow::~MainWidow()
{
    delete ui;
}

void MainWidow::on_pushButtonClose_clicked()
{

}

ifstream inFile;
bool controlBits[22];
int passCount = 0;
char opcode[3];
char cycleNumber[3];
int PC = 0;
int SP = 0;
int OR = 0;
int IR_reg = 0;
int registerArray[8];
int flagArray[8];
int memoryContents[256];
int currentNew = -1;

void MainWidow::on_nextStage_clicked()
{
    inFile.open("output");
    inFile.seekg(0,ios::end);
//    qDebug()<<inFile.tellg()<<"--"<<currentPosition;
    if(inFile.tellg()-1 == currentPosition)
    {
        qDebug()<<"FULL TO THE BRIM";
        ofstream f1("sig.dat");

        ui->pushButton->setEnabled(false);
        ui->pushButton_2->setEnabled(false);
        ui->reset->setEnabled(false);
        ui->nextStage->setEnabled(false);

        f1<<"2"<<'\n';
        f1.close();
        QApplication::processEvents();
        QThread::sleep(3); // 3 second

        ui->pushButton->setEnabled(true);
        ui->pushButton_2->setEnabled(true);
        ui->reset->setEnabled(true);
        ui->nextStage->setEnabled(true);

        ofstream f2("sig.dat");
        f2<<0<<'\n';
        f2.close();
    }
    inFile.seekg(0);
    if(currentPosition!= -1)
    {
        for(int j=0;j<(43+256)*passCount;j++)
        {
            inFile >> temp;
        }
        for(int i = 0; i<22; i++)
        {
            inFile >> controlBits[i];
        }
        if(!inFile.eof())
            inFile >> cycleNumber;
        if(!inFile.eof())
            inFile >> PC;
        if(!inFile.eof())
            inFile >> SP;
        if(!inFile.eof())
            inFile >> OR;
        if(!inFile.eof())
            inFile >> IR_reg;
        int cacheTemp;
        for(int u = 0; u<8 && (!inFile.eof()); u++){
            inFile >> flagArray[u];
        }
        for(int u = 0; u<8 && (!inFile.eof()); u++){
            cacheTemp = registerArray[u];
            inFile >> registerArray[u];
            if(cacheTemp != registerArray[u])
                currentNew = u;
        }
        for(int u = 0; u<256 && (!inFile.eof()); u++){
            inFile >> memoryContents[u];
        }
        passCount++;
        currentPosition = inFile.tellg();
    }

    inFile.close();
    if(controlBits[0]&&(!controlBits[1])&&controlBits[2]&&(!controlBits[3])&&(!controlBits[4])&&controlBits[5]&&(!controlBits[6])&&(!controlBits[7])&&(!controlBits[8])&&(!controlBits[9])&&controlBits[10]&&(!controlBits[11])&&(!controlBits[12])&&(!controlBits[13])&&(!controlBits[14])&&(!controlBits[15])&&(!controlBits[16])&&(!controlBits[17])&&(!controlBits[18])&&(!controlBits[19])&&(!controlBits[20])&&(!controlBits[21]))
        executionState = 0;
        //        1 0 1 0
//        0 1 0 0
//        0 0 1 0
//        0 0 0 0
//        0 0 0 0
//        0 0
    char tempString[10];
    sprintf(tempString,"%d",executionState++);

    ui->state->setText(tempString);

    sprintf(tempString,"%X",PC);
    ui->PC_value->setText(tempString);
    sprintf(tempString,"%X",(SP+256 - 1)%256);
    ui->SP_value->setText(tempString);
    sprintf(tempString,"%X",OR);
    ui->OR_value->setText(tempString);

    sprintf(tempString,"Opcode : %X",IR_reg);
    ui->IR_value->setText(tempString);

    char output[50];
    switch(IR_reg){
        case 0: strcpy(output,"NOP"); break;
        case 1: strcpy(output,"CLR"); break;
        case 2: strcpy(output,"CLC"); break;
        case 3: strcpy(output,"JUD <od>"); break;

        case 4: strcpy(output,"JUA "); break;
        case 5: strcpy(output,"CUD <od>"); break;

        case 6: strcpy(output,"CUA "); break;

        case 7: strcpy(output,"RTU"); break;
        case 8: strcpy(output,"JCD Z  <od>"); break;
        case 9: strcpy(output,"JCD NZ <od>"); break;
        case 10: strcpy(output,"JCD C <od>"); break;
        case 11: strcpy(output,"JCD NC <od>"); break;
        case 12: strcpy(output,"JCD P <od>"); break;
        case 13: strcpy(output,"JCD N <od>"); break;
        case 14: strcpy(output,"JCD OP <od>"); break;
        case 15: strcpy(output,"JCD EP <od>"); break;
        case 16: strcpy(output,"LSP "); break;
        case 17: strcpy(output,"MVD R1"); break;
        case 18: strcpy(output,"MVD R2"); break;
        case 19: strcpy(output,"MVD R3"); break;
        case 20: strcpy(output,"MVD R4"); break;
        case 21: strcpy(output,"MVD R5"); break;
        case 22: strcpy(output,"MVD R6"); break;
        case 23: strcpy(output,"MVD R7"); break;
        case 24: strcpy(output,"RSP"); break;
        case 25: strcpy(output,"MVS R1"); break;
        case 26: strcpy(output,"MVS R2"); break;
        case 27: strcpy(output,"MVS R3"); break;
        case 28: strcpy(output,"MVS R4"); break;
        case 29: strcpy(output,"MVS R5"); break;
        case 30: strcpy(output,"MVS R6"); break;
        case 31: strcpy(output,"MVS R7"); break;
        case 32: strcpy(output,"NOT R0"); break;
        case 33: strcpy(output,"NOT R1"); break;
        case 34: strcpy(output,"NOT R2"); break;
        case 35: strcpy(output,"NOT R3"); break;
        case 36: strcpy(output,"NOT R4"); break;
        case 37: strcpy(output,"NOT R5"); break;
        case 38: strcpy(output,"NOT R6"); break;
        case 39: strcpy(output,"NOT R7"); break;
        case 40: strcpy(output,"JCA Z "); break;
        case 41: strcpy(output,"JCA NZ"); break;
        case 42: strcpy(output,"JCA C "); break;
        case 43: strcpy(output,"JCA NC"); break;
        case 44: strcpy(output,"JCA P "); break;
        case 45: strcpy(output,"JCA N "); break;
        case 46: strcpy(output,"JCA OP"); break;
        case 47: strcpy(output,"JCA EP"); break;
        case 48: strcpy(output,"CCD Z <od>"); break;
        case 49: strcpy(output,"CCD NZ <od>"); break;
        case 50: strcpy(output,"CCD C <od>"); break;
        case 51: strcpy(output,"CCD NC <od>"); break;
        case 52: strcpy(output,"CCD P <od>"); break;
        case 53: strcpy(output,"CCD N <od>"); break;
        case 54: strcpy(output,"CCD OP <od>"); break;
        case 55: strcpy(output,"CCD EP <od>"); break;
        case 56: strcpy(output,"CCA Z "); break;
        case 57: strcpy(output,"CCA NZ"); break;
        case 58: strcpy(output,"CCA C "); break;
        case 59: strcpy(output,"CCA NC"); break;
        case 60: strcpy(output,"CCA P "); break;
        case 61: strcpy(output,"CCA N "); break;
        case 62: strcpy(output,"CCA OP"); break;
        case 63: strcpy(output,"CCA EP"); break;
        case 64: strcpy(output,"INC R0"); break;
        case 65: strcpy(output,"INC R1"); break;
        case 66: strcpy(output,"INC R2"); break;
        case 67: strcpy(output,"INC R3"); break;
        case 68: strcpy(output,"INC R4"); break;
        case 69: strcpy(output,"INC R5"); break;
        case 70: strcpy(output,"INC R6"); break;
        case 71: strcpy(output,"INC R7"); break;
        case 72: strcpy(output,"RTC Z "); break;
        case 73: strcpy(output,"RTC NZ"); break;
        case 74: strcpy(output,"RTC C "); break;
        case 75: strcpy(output,"RTC NC"); break;
        case 76: strcpy(output,"RTC P "); break;
        case 77: strcpy(output,"RTC N "); break;
        case 78: strcpy(output,"RTC OP"); break;
        case 79: strcpy(output,"RTC EP"); break;
        case 80: strcpy(output,"DCR R0"); break;
        case 81: strcpy(output,"DCR R1"); break;
        case 82: strcpy(output,"DCR R2"); break;
        case 83: strcpy(output,"DCR R3"); break;
        case 84: strcpy(output,"DCR R4"); break;
        case 85: strcpy(output,"DCR R5"); break;
        case 86: strcpy(output,"DCR R6"); break;
        case 87: strcpy(output,"DCR R7"); break;
        case 88: strcpy(output,"MVI R0 <od>"); break;
        case 89: strcpy(output,"MVI R1 <od>"); break;
        case 90: strcpy(output,"MVI R2 <od>"); break;
        case 91: strcpy(output,"MVI R3 <od>"); break;
        case 92: strcpy(output,"MVI R4 <od>"); break;
        case 93: strcpy(output,"MVI R5 <od>"); break;
        case 94: strcpy(output,"MVI R6 <od>"); break;
        case 95: strcpy(output,"MVI R7 <od>"); break;
        case 96: strcpy(output,"RLA"); break;
        case 97: strcpy(output,"STA R1"); break;
        case 98: strcpy(output,"STA R2"); break;
        case 99: strcpy(output,"STA R3"); break;
        case 100: strcpy(output,"STA R4"); break;
        case 101: strcpy(output,"STA R5"); break;
        case 102: strcpy(output,"STA R6"); break;
        case 103: strcpy(output,"STA R7"); break;
        case 104: strcpy(output,"PSH R0"); break;
        case 105: strcpy(output,"PSH R1"); break;
        case 106: strcpy(output,"PSH R2"); break;
        case 107: strcpy(output,"PSH R3"); break;
        case 108: strcpy(output,"PSH R4"); break;
        case 109: strcpy(output,"PSH R5"); break;
        case 110: strcpy(output,"PSH R6"); break;
        case 111: strcpy(output,"PSH R7"); break;
        case 112: strcpy(output,"RRA"); break;
        case 113: strcpy(output,"LDA R1"); break;
        case 114: strcpy(output,"LDA R2"); break;
        case 115: strcpy(output,"LDA R3"); break;
        case 116: strcpy(output,"LDA R4"); break;
        case 117: strcpy(output,"LDA R5"); break;
        case 118: strcpy(output,"LDA R6"); break;
        case 119: strcpy(output,"LDA R7"); break;
        case 120: strcpy(output,"POP R0"); break;
        case 121: strcpy(output,"POP R1"); break;
        case 122: strcpy(output,"POP R2"); break;
        case 123: strcpy(output,"POP R3"); break;
        case 124: strcpy(output,"POP R4"); break;
        case 125: strcpy(output,"POP R5"); break;
        case 126: strcpy(output,"POP R6"); break;
        case 127: strcpy(output,"POP R7"); break;
        case 128: strcpy(output,"ADA R0"); break;
        case 129: strcpy(output,"ADA R1"); break;
        case 130: strcpy(output,"ADA R2"); break;
        case 131: strcpy(output,"ADA R3"); break;
        case 132: strcpy(output,"ADA R4"); break;
        case 133: strcpy(output,"ADA R5"); break;
        case 134: strcpy(output,"ADA R6"); break;
        case 135: strcpy(output,"ADA R7"); break;
        case 136: strcpy(output,"ADI R0 <od>"); break;
        case 137: strcpy(output,"ADI R1 <od>"); break;
        case 138: strcpy(output,"ADI R2 <od>"); break;
        case 139: strcpy(output,"ADI R3 <od>"); break;
        case 140: strcpy(output,"ADI R4 <od>"); break;
        case 141: strcpy(output,"ADI R5 <od>"); break;
        case 142: strcpy(output,"ADI R6 <od>"); break;
        case 143: strcpy(output,"ADI R7 <od>"); break;
        case 144: strcpy(output,"SBA R0"); break;
        case 145: strcpy(output,"SBA R1"); break;
        case 146: strcpy(output,"SBA R2"); break;
        case 147: strcpy(output,"SBA R3"); break;
        case 148: strcpy(output,"SBA R4"); break;
        case 149: strcpy(output,"SBA R5"); break;
        case 150: strcpy(output,"SBA R6"); break;
        case 151: strcpy(output,"SBA R7"); break;
        case 152: strcpy(output,"SBI R0 <od>"); break;
        case 153: strcpy(output,"SBI R1 <od>"); break;
        case 154: strcpy(output,"SBI R2 <od>"); break;
        case 155: strcpy(output,"SBI R3 <od>"); break;
        case 156: strcpy(output,"SBI R4 <od>"); break;
        case 157: strcpy(output,"SBI R5 <od>"); break;
        case 158: strcpy(output,"SBI R6 <od>"); break;
        case 159: strcpy(output,"SBI R7 <od>"); break;
        case 160: strcpy(output,"ACA R0"); break;
        case 161: strcpy(output,"ACA R1"); break;
        case 162: strcpy(output,"ACA R2"); break;
        case 163: strcpy(output,"ACA R3"); break;
        case 164: strcpy(output,"ACA R4"); break;
        case 165: strcpy(output,"ACA R5"); break;
        case 166: strcpy(output,"ACA R6"); break;
        case 167: strcpy(output,"ACA R7"); break;
        case 168: strcpy(output,"ACI R0 <od>"); break;
        case 169: strcpy(output,"ACI R1 <od>"); break;
        case 170: strcpy(output,"ACI R2 <od>"); break;
        case 171: strcpy(output,"ACI R3 <od>"); break;
        case 172: strcpy(output,"ACI R4 <od>"); break;
        case 173: strcpy(output,"ACI R5 <od>"); break;
        case 174: strcpy(output,"ACI R6 <od>"); break;
        case 175: strcpy(output,"ACI R7 <od>"); break;
        case 176: strcpy(output,"SCA R0"); break;
        case 177: strcpy(output,"SCA R1"); break;
        case 178: strcpy(output,"SCA R2"); break;
        case 179: strcpy(output,"SCA R3"); break;
        case 180: strcpy(output,"SCA R4"); break;
        case 181: strcpy(output,"SCA R5"); break;
        case 182: strcpy(output,"SCA R6"); break;
        case 183: strcpy(output,"SCA R7"); break;
        case 184: strcpy(output,"SCI R0 <od>"); break;
        case 185: strcpy(output,"SCI R1 <od>"); break;
        case 186: strcpy(output,"SCI R2 <od>"); break;
        case 187: strcpy(output,"SCI R3 <od>"); break;
        case 188: strcpy(output,"SCI R4 <od>"); break;
        case 189: strcpy(output,"SCI R5 <od>"); break;
        case 190: strcpy(output,"SCI R6 <od>"); break;
        case 191: strcpy(output,"SCI R7 <od>"); break;
        case 192: strcpy(output,"ANA R0"); break;
        case 193: strcpy(output,"ANA R1"); break;
        case 194: strcpy(output,"ANA R2"); break;
        case 195: strcpy(output,"ANA R3"); break;
        case 196: strcpy(output,"ANA R4"); break;
        case 197: strcpy(output,"ANA R5"); break;
        case 198: strcpy(output,"ANA R6"); break;
        case 199: strcpy(output,"ANA R7"); break;
        case 200: strcpy(output,"ANI R0 <od>"); break;
        case 201: strcpy(output,"ANI R1 <od>"); break;
        case 202: strcpy(output,"ANI R2 <od>"); break;
        case 203: strcpy(output,"ANI R3 <od>"); break;
        case 204: strcpy(output,"ANI R4 <od>"); break;
        case 205: strcpy(output,"ANI R5 <od>"); break;
        case 206: strcpy(output,"ANI R6 <od>"); break;
        case 207: strcpy(output,"ANI R7 <od>"); break;
        case 208: strcpy(output,"ORA R0"); break;
        case 209: strcpy(output,"ORA R1"); break;
        case 210: strcpy(output,"ORA R2"); break;
        case 211: strcpy(output,"ORA R3"); break;
        case 212: strcpy(output,"ORA R4"); break;
        case 213: strcpy(output,"ORA R5"); break;
        case 214: strcpy(output,"ORA R6"); break;
        case 215: strcpy(output,"ORA R7"); break;
        case 216: strcpy(output,"ORI R0 <od>"); break;
        case 217: strcpy(output,"ORI R1 <od>"); break;
        case 218: strcpy(output,"ORI R2 <od>"); break;
        case 219: strcpy(output,"ORI R3 <od>"); break;
        case 220: strcpy(output,"ORI R4 <od>"); break;
        case 221: strcpy(output,"ORI R5 <od>"); break;
        case 222: strcpy(output,"ORI R6 <od>"); break;
        case 223: strcpy(output,"ORI R7 <od>"); break;
        case 224: strcpy(output,"XRA R0"); break;
        case 225: strcpy(output,"XRA R1"); break;
        case 226: strcpy(output,"XRA R2"); break;
        case 227: strcpy(output,"XRA R3"); break;
        case 228: strcpy(output,"XRA R4"); break;
        case 229: strcpy(output,"XRA R5"); break;
        case 230: strcpy(output,"XRA R6"); break;
        case 231: strcpy(output,"XRA R7"); break;
        case 232: strcpy(output,"XRI R0 <od>"); break;
        case 233: strcpy(output,"XRI R1 <od>"); break;
        case 234: strcpy(output,"XRI R2 <od>"); break;
        case 235: strcpy(output,"XRI R3 <od>"); break;
        case 236: strcpy(output,"XRI R4 <od>"); break;
        case 237: strcpy(output,"XRI R5 <od>"); break;
        case 238: strcpy(output,"XRI R6 <od>"); break;
        case 239: strcpy(output,"XRI R7 <od>"); break;
        case 240: strcpy(output,"INA P0"); break;
        case 241: strcpy(output,"INA P1"); break;
        case 242: strcpy(output,"INA P2"); break;
        case 243: strcpy(output,"INA P3"); break;
        case 244: strcpy(output,"INA P4"); break;
        case 245: strcpy(output,"INA P5"); break;
        case 246: strcpy(output,"INA P6"); break;
        case 247: strcpy(output,"INA P7"); break;
        case 248: strcpy(output,"OUT P0"); break;
        case 249: strcpy(output,"OUT P1"); break;
        case 250: strcpy(output,"OUT P2"); break;
        case 251: strcpy(output,"OUT P3"); break;
        case 252: strcpy(output,"OUT P4"); break;
        case 253: strcpy(output,"OUT P5"); break;
        case 254: strcpy(output,"OUT P6"); break;
        case 255: strcpy(output,"OUT P7"); break;
    }

    char tempOutAppended[50];
    strcpy(tempOutAppended,"Instruction : ");
    strcat(tempOutAppended,output);


    QPalette* redColor = new QPalette();
    redColor->setColor(QPalette::WindowText,Qt::red);

    QPalette* blackColor = new QPalette();
    blackColor->setColor(QPalette::WindowText,Qt::black);

//    ui->Instruction_value->setPalette(*palette);
    ui->Instruction_value->setText(tempOutAppended);

    sprintf(tempString,"%X",registerArray[0]);
    ui->R0_value->setPalette(*blackColor);
    ui->R0_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[1]);
    ui->R1_value->setPalette(*blackColor);
    ui->R1_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[2]);
    ui->R2_value->setPalette(*blackColor);
    ui->R2_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[3]);
    ui->R3_value->setPalette(*blackColor);
    ui->R3_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[4]);
    ui->R4_value->setPalette(*blackColor);
    ui->R4_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[5]);
    ui->R5_value->setPalette(*blackColor);
    ui->R5_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[6]);
    ui->R6_value->setPalette(*blackColor);
    ui->R6_value->setText(tempString);
    sprintf(tempString,"%X",registerArray[7]);
    ui->R7_value->setPalette(*blackColor);
    ui->R7_value->setText(tempString);


    switch(currentNew){
    case 0:
        ui->R0_value->setPalette(*redColor);
        break;
    case 1:
        ui->R1_value->setPalette(*redColor);
        break;
    case 2:
        ui->R2_value->setPalette(*redColor);
        break;
    case 3:
        ui->R3_value->setPalette(*redColor);
        break;
    case 4:
        ui->R4_value->setPalette(*redColor);
        break;
    case 5:
        ui->R5_value->setPalette(*redColor);
        break;
    case 6:
        ui->R6_value->setPalette(*redColor);
        break;
    case 7:
        ui->R7_value->setPalette(*redColor);
        break;
    default:
        break;
    }


    sprintf(tempString,"%X",flagArray[0]);
//    ui->R0_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[1]);
//    ui->R1_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[2]);
//    ui->R2_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[3]);
//    ui->R3_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[4]);
//    ui->R4_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[5]);
//    ui->R5_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[6]);
//    ui->R6_value_2->setText(tempString);
    sprintf(tempString,"%X",flagArray[7]);
//    ui->R7_value_2->setText(tempString);


    ui->imageLabel->setVisible((bool)controlBits[0]);
    ui->imageLabel_2->setVisible((bool)controlBits[1]);
    ui->imageLabel_3->setVisible((bool)controlBits[2]);
    ui->imageLabel_4->setVisible((bool)controlBits[3]);
    ui->imageLabel_5->setVisible((bool)controlBits[4]);
    ui->imageLabel_6->setVisible((bool)controlBits[5]);
    ui->imageLabel_7->setVisible((bool)controlBits[6]);
    ui->imageLabel_39->setVisible((bool)controlBits[6]);
    ui->imageLabel_8->setVisible((bool)controlBits[7]);
    ui->imageLabel_9->setVisible((bool)controlBits[8]);
    ui->imageLabel_10->setVisible((bool)controlBits[9]);
    ui->imageLabel_11->setVisible((bool)controlBits[10]);
    ui->imageLabel_12->setVisible((bool)controlBits[11]);
    ui->imageLabel_13->setVisible((bool)controlBits[12]);
    ui->imageLabel_14->setVisible((bool)controlBits[13]);
    ui->imageLabel_15->setVisible((bool)controlBits[14]);
    ui->imageLabel_16->setVisible((bool)controlBits[15]);
    ui->imageLabel_17->setVisible((bool)controlBits[16]);
    ui->imageLabel_18->setVisible((bool)controlBits[17]);
    ui->imageLabel_19->setVisible((bool)controlBits[18]);
    ui->imageLabel_20->setVisible((bool)controlBits[19]);
    ui->imageLabel_21->setVisible((bool)controlBits[20]);
    ui->imageLabel_22->setVisible((bool)controlBits[21]);
    ui->imageLabel_23->setVisible((bool)(controlBits[0]+controlBits[4]+controlBits[11]+controlBits[13]+controlBits[15]+controlBits[19]+controlBits[21]));
    ui->imageLabel_24->setVisible(((bool)controlBits[8])&((bool)controlBits[9]));
    ui->imageLabel_27->setVisible(controlBits[18]);
    ui->imageLabel_26->setVisible(controlBits[20]);
    ui->imageLabel_35->setVisible(controlBits[17]);

    ui->imageLabel_28->setVisible(flagArray[2]);
    ui->imageLabel_29->setVisible(flagArray[3]);
    ui->imageLabel_30->setVisible(flagArray[0]);
    ui->imageLabel_31->setVisible(flagArray[1]);
    ui->imageLabel_32->setVisible(flagArray[4]);
    ui->imageLabel_33->setVisible(flagArray[5]);
    ui->imageLabel_34->setVisible(flagArray[6]);
    ui->imageLabel_35->setVisible(flagArray[7]);
    ui->imageLabel_38->setVisible(controlBits[5]&&controlBits[6]);
//    ui->imageLabel_37->setVisible(controlBits[5]&&controlBits[6]);



    ui->imageLabel_40->setVisible((!controlBits[3])&&(!controlBits[2])&&(controlBits[0]||controlBits[1]));
    if(controlBits[5]&&controlBits[6])
        ui->imageLabel_7->setVisible(false);

    ui->imageLabel_37->setVisible(controlBits[6]&&controlBits[7]);
    ui->imageLabel_36->setVisible(controlBits[17]);
    if((controlBits[18]&&controlBits[20])||controlBits[17])
    {
        ui->imageLabel_19->setVisible(false);
        ui->imageLabel_21->setVisible(false);
    }
    ui->OR_value->setVisible(false);
    ui->label_2->setVisible(false);

    if(controlBits[15]||controlBits[16]||controlBits[17]||(controlBits[5]&&controlBits[6]))
    {
        ui->OR_value->setVisible(true);
        ui->label_2->setVisible(true);
    }
    char tempOut[5];
    for(int j=0;j<256;j++){
//        qInfo() << memoryContents[j];
        sprintf(tempString,"%X",memoryContents[j]);
        sprintf(tempOut,"%X",j);
        table->setItem(j, 0, new QTableWidgetItem(tempOut));
        table->setItem(j, 1, new QTableWidgetItem(tempString));
    }


    int localTOS = (SP+256 - 1)%256;
    char tempHolder[10];
    int heightOfStack = 255 - localTOS;
    if(heightOfStack < 0)
        heightOfStack = 0;

    stack->setColumnCount(1);
    stack->setRowCount(heightOfStack);
    for(int l=0;l<heightOfStack;l++)
    {
        sprintf(tempHolder,"%X",memoryContents[255-heightOfStack+l+1]);
        stack->setItem(l, 0, new QTableWidgetItem(tempHolder));
    }

    if(!isFirstFetch)
    {
        ui->Instruction_value->setText("Instruction : XX");
        ui->R0_value->setText("XX");
        ui->R1_value->setText("XX");
        ui->R2_value->setText("XX");
        ui->R3_value->setText("XX");
        ui->R4_value->setText("XX");
        ui->R5_value->setText("XX");
        ui->R6_value->setText("XX");
        ui->R7_value->setText("XX");
    }
    isFirstFetch = true;
//    inFile.close();
}

void visualDelay()
{
    QTime dieTime= QTime::currentTime().addSecs(1);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void delay()
{
    QTime dieTime= QTime::currentTime().addSecs(1);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void doFileOperation(QProcess* p, QStringList params)
{
    (*p).start("python",params);
    (*p).waitForFinished(-1);
//    process->startDetached("runMe.bat");
}
void doFileOperationDetached(QProcess* p)
{
    process->startDetached("runMe.bat");
}
int isAlive = 0;

void MainWidow::on_pushButton_clicked()
{
//    ui->logBox->setText("Emulator running, please wait\n");
    //Commit text to file
    if(isAlive == 0)
    {
        QString boxToFile;
        QFile file("user_input.txt");
        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
            return;

        QTextStream out(&file);


        boxToFile = ui->plainTextEdit->toPlainText();
        out << boxToFile;
        file.close();

        QProcess *process;
        process = new QProcess(this);

        doFileOperationDetached(process);

        isAlive = 1;

        ui->pushButton->setEnabled(false);
        ui->pushButton_2->setEnabled(false);
        ui->reset->setEnabled(false);
        ui->nextStage->setEnabled(false);

        visualDelay();
        visualDelay();
//        visualDelay();
        on_pushButton_2_clicked();
    //    on_reset_clicked();
        for(int delayer = 0; delayer <10;delayer++)
            visualDelay();
        ui->pushButton->setEnabled(true);
        ui->pushButton_2->setEnabled(true);
        ui->reset->setEnabled(true);
        ui->nextStage->setEnabled(true);

    }
    else{
        on_reset_clicked();
        ofstream f1 ("sig.dat");

        ui->pushButton->setEnabled(false);
        ui->pushButton_2->setEnabled(false);
        ui->reset->setEnabled(false);
        ui->nextStage->setEnabled(false);
        //  0   -   WAIT
        //  1   -   KILL
        //  2   -   MORE
        f1<<"1"<<'\n';

        f1.close();
        ui->logBox->setText("Killing current execution. Please Wait.");
        QApplication::processEvents();
        QThread::sleep(6); // 1 second
        ui->logBox->setText("Compiling.");
        ui->pushButton->setEnabled(true);
        ui->pushButton_2->setEnabled(true);
        ui->reset->setEnabled(true);
        ui->nextStage->setEnabled(true);

        f1.open("sig.dat");
        f1<<"0"<<'\n';
        f1.close();
        isAlive = 0;

        on_pushButton_clicked();
    }
}
void MainWidow::on_pushButton_2_clicked()
{
    char line[100], outLine[1000];
    strcpy(line,"");
    strcpy(outLine,"");
    ifstream myfile ("log.txt");
    if (myfile.is_open())
    {
        while ( myfile.getline(line,100) )
        {
            strcat(outLine,line);
            strcat(outLine,"\n");
        }
        myfile.close();
    }
    char tempLog[1000];
    strcpy(tempLog,"Log:\n");
    strcat(tempLog,outLine);
    ui->logBox->setText(tempLog);
    myfile.close();
}

void MainWidow::on_reset_clicked()
{
    passCount = 0;
    MainWidow::on_nextStage_clicked();
    ui->Instruction_value->setText("Instruction : XX");
    ui->R0_value->setText("XX");
    ui->R1_value->setText("XX");
    ui->R2_value->setText("XX");
    ui->R3_value->setText("XX");
    ui->R4_value->setText("XX");
    ui->R5_value->setText("XX");
    ui->R6_value->setText("XX");
    ui->R7_value->setText("XX");
}

void MainWidow::on_run10ClockCycle_clicked()
{
//    for(int i = 0; i<10; i++)
//    {
//        on_nextStage_clicked();
//        visualDelay();
//    }
}
bool fileExists(QString path) {
    QFileInfo check_file(path);
    // check if file exists and if yes: Is it really a file and no directory?
    return check_file.exists() && check_file.isFile();
}
